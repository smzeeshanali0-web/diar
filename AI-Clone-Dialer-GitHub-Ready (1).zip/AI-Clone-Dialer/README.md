# AI Clone Dialer

![Android Build](../../actions/workflows/android-build.yml/badge.svg) ![Backend Tests](../../actions/workflows/backend-tests.yml/badge.svg)

GitHub-ready starter repository for an Android SIP/VoIP dialer with an authorized AI voice-profile workflow.

## Important status

This repository is a **buildable application foundation**, not a production-complete telephony/voice-cloning product. A real SIP provider account and a licensed streaming voice-conversion provider/model are required before real calls can use converted speech. The Android project includes a clear SIP integration boundary; the backend includes a provider interface and consent checks. It does not pretend to clone voices or convert live calls without those integrations.

Use only voice recordings you own or have explicit permission to use. The app displays an AI-voice disclosure notice in the call UI.

## Repository layout

- `android-app/` — Kotlin + Jetpack Compose Android app, persistent SIP settings, persistent default voice selection, dialer and call UI.
- `ai-backend/` — FastAPI service for voice sample upload, voice-profile metadata, consent acknowledgement and provider integration boundary.
- `docs/` — integration and testing notes.

## Build Android APK

Requirements: Android Studio (current stable), JDK 17, Android SDK 35.

1. Open `android-app/` in Android Studio.
2. Allow Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Debug APK output: `android-app/app/build/outputs/apk/debug/app-debug.apk`.

Or from a terminal in `android-app/` (needs Gradle 8.9+ installed):

```bash
gradle wrapper --gradle-version 8.9   # one time, creates ./gradlew
./gradlew assembleDebug
```

### GitHub Actions (automatic APK build)

Every push to `main` builds the debug APK via `.github/workflows/android-build.yml`.
Download it from the repo's **Actions** tab > latest run > **Artifacts** > `app-debug-apk`.
You can also trigger it manually with **Run workflow**. The workflow installs Gradle itself, so no wrapper is needed in CI.

## Run backend

Python 3.11+:

```bash
cd ai-backend
python -m venv .venv
# Windows: .venv\Scripts\activate
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

API docs: `http://127.0.0.1:8000/docs`

Set `AI_PROVIDER_BASE_URL` and `AI_PROVIDER_API_KEY` only after selecting a licensed provider that supports authorized voice profiles and streaming voice conversion. The current adapter intentionally returns `501 Not Implemented` until a real provider adapter is configured.

## SIP integration

The Android app saves editable SIP account settings locally using Android DataStore. Actual SIP registration, RTP media, incoming calls and outgoing calls require a SIP SDK/native engine such as PJSIP or another SDK licensed for your use. Implement it behind `SipEngine` in `android-app/app/src/main/java/com/aiclone/dialer/sip/`.

Do not put SIP passwords or provider API keys in source control. For production, use Android Keystore-backed encryption and a secure backend secret store.

## GitHub

Create a private GitHub repository, then:

```bash
git init
git add .
git commit -m "Initial AI Clone Dialer project"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/AI-Clone-Dialer.git
git push -u origin main
```

No GitHub credentials are included, so this archive does not publish itself.
