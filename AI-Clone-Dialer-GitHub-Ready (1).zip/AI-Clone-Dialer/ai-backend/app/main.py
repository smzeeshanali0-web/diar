from __future__ import annotations

import os
import uuid
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from pydantic import BaseModel, Field

APP_DIR = Path(__file__).resolve().parent
UPLOAD_DIR = APP_DIR.parent / "uploads"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "20"))
ALLOWED = {".mp3", ".wav", ".m4a"}

app = FastAPI(
    title="AI Clone Dialer Backend",
    version="0.1.0",
    description="Consent-based voice-profile API foundation. Configure a licensed AI provider for actual cloning/streaming."
)

# Replace with PostgreSQL-backed persistence and authenticated ownership in production.
profiles: dict[str, dict] = {}


class ProfileRename(BaseModel):
    name: str = Field(min_length=1, max_length=80)


class ConsentRecord(BaseModel):
    voice_owner_authorized: bool
    disclosure_acknowledged: bool


@app.get("/health")
def health():
    return {"status": "ok", "service": "ai-clone-dialer-backend"}


@app.post("/v1/voice-samples")
async def upload_voice_sample(
    file: UploadFile = File(...),
    profile_name: str = Form(..., min_length=1, max_length=80),
    voice_owner_authorized: bool = Form(...),
    disclosure_acknowledged: bool = Form(...)
):
    if not voice_owner_authorized or not disclosure_acknowledged:
        raise HTTPException(403, "Explicit voice-owner authorization and AI disclosure acknowledgement are required.")
    suffix = Path(file.filename or "").suffix.lower()
    if suffix not in ALLOWED:
        raise HTTPException(415, "Supported formats: MP3, WAV, M4A.")
    sample_id = str(uuid.uuid4())
    destination = UPLOAD_DIR / f"{sample_id}{suffix}"
    size = 0
    with destination.open("wb") as out:
        while chunk := await file.read(1024 * 1024):
            size += len(chunk)
            if size > MAX_UPLOAD_MB * 1024 * 1024:
                destination.unlink(missing_ok=True)
                raise HTTPException(413, f"File exceeds {MAX_UPLOAD_MB} MB limit.")
            out.write(chunk)
    profiles[sample_id] = {
        "id": sample_id,
        "name": profile_name,
        "sample_file": str(destination),
        "status": "uploaded_pending_provider",
        "voice_owner_authorized": True,
        "disclosure_acknowledged": True,
    }
    return {
        "sample_id": sample_id,
        "name": profile_name,
        "status": "uploaded_pending_provider",
        "message": "Sample stored. Configure a licensed provider adapter to create a real voice model."
    }


@app.get("/v1/voice-profiles")
def list_profiles():
    return {"items": [
        {k: v for k, v in p.items() if k != "sample_file"}
        for p in profiles.values()
    ]}


@app.patch("/v1/voice-profiles/{profile_id}")
def rename_profile(profile_id: str, body: ProfileRename):
    if profile_id not in profiles:
        raise HTTPException(404, "Voice profile not found.")
    profiles[profile_id]["name"] = body.name
    return {"id": profile_id, "name": body.name}


@app.delete("/v1/voice-profiles/{profile_id}")
def delete_profile(profile_id: str):
    profile = profiles.pop(profile_id, None)
    if not profile:
        raise HTTPException(404, "Voice profile not found.")
    Path(profile["sample_file"]).unlink(missing_ok=True)
    return {"deleted": True}


@app.post("/v1/voice-profiles/{profile_id}/clone")
def create_clone(profile_id: str):
    if profile_id not in profiles:
        raise HTTPException(404, "Voice profile not found.")
    # Deliberately fail closed: never pretend a clone was generated.
    if not os.getenv("AI_PROVIDER_BASE_URL") or not os.getenv("AI_PROVIDER_API_KEY"):
        raise HTTPException(
            501,
            "No licensed AI voice provider configured. Set provider credentials and implement the provider adapter."
        )
    raise HTTPException(
        501,
        "Provider credentials detected, but the provider-specific clone adapter is not implemented. See docs/PRODUCTION_INTEGRATION.md."
    )


@app.post("/v1/voice-conversion/session")
def create_conversion_session(profile_id: str):
    if profile_id not in profiles:
        raise HTTPException(404, "Voice profile not found.")
    raise HTTPException(
        501,
        "Streaming conversion requires a configured licensed provider adapter. Raw microphone fallback is not permitted."
    )
