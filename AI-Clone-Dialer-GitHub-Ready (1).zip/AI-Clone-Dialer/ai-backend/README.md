# AI backend

This API currently provides health checks, authorized sample upload, profile metadata, rename and delete. Actual cloning and streaming conversion intentionally return HTTP 501 until a licensed provider adapter is implemented.

Run:

```bash
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Do not expose this development server publicly. Add authentication, PostgreSQL persistence, encrypted object storage, TLS, rate limits and retention controls before production.
