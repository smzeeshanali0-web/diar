package com.aiclone.dialer.sip

import com.aiclone.dialer.data.SipAccount

enum class SipEngineStatus { NOT_CONFIGURED, REGISTERING, REGISTERED, FAILED, IN_CALL }

interface SipEngine {
    suspend fun register(account: SipAccount): SipEngineStatus
    suspend fun unregister(accountId: String)
    suspend fun makeCall(destination: String, accountId: String, outgoingAudio: OutgoingAudioProcessor): Result<Unit>
    suspend fun answer()
    suspend fun hangup()
    suspend fun setMuted(muted: Boolean)
    suspend fun sendDtmf(digit: Char)
}

/**
 * Production adapter boundary.
 *
 * Implement with a licensed SIP SDK such as PJSIP/PJSUA2. The adapter must:
 * - authenticate and register accounts,
 * - negotiate codecs and RTP,
 * - route outgoing microphone PCM through OutgoingAudioProcessor before RTP encoding,
 * - leave incoming audio untouched,
 * - fail closed when AI conversion is enabled but unavailable.
 *
 * This class intentionally does not simulate successful registration or calls.
 */
interface OutgoingAudioProcessor {
    suspend fun processPcm16(input: ShortArray, sampleRate: Int, channels: Int): ShortArray
}
