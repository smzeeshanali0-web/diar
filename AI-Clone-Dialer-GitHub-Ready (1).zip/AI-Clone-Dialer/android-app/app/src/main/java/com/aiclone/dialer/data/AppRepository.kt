package com.aiclone.dialer.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.dataStore by preferencesDataStore(name = "ai_clone_dialer")
class AppRepository(private val context: Context) {
    private val accountsKey = stringPreferencesKey("sip_accounts")
    private val voicesKey = stringPreferencesKey("voice_profiles")
    private val defaultVoiceKey = stringPreferencesKey("default_voice")
    private val aiEnabledKey = booleanPreferencesKey("ai_enabled")

    val accounts: Flow<List<SipAccount>> = context.dataStore.data.map { prefs ->
        decodeAccounts(prefs[accountsKey] ?: "[]")
    }
    val voices: Flow<List<VoiceProfile>> = context.dataStore.data.map { prefs ->
        decodeVoices(prefs[voicesKey] ?: "[]")
    }
    val defaultVoice: Flow<String> = context.dataStore.data.map { it[defaultVoiceKey] ?: "" }
    val aiEnabled: Flow<Boolean> = context.dataStore.data.map { it[aiEnabledKey] ?: true }

    suspend fun saveAccount(account: SipAccount) {
        context.dataStore.edit { prefs ->
            val list = decodeAccounts(prefs[accountsKey] ?: "[]").toMutableList()
            list.removeAll { it.id == account.id }
            list.add(account)
            prefs[accountsKey] = encodeAccounts(list)
        }
    }
    suspend fun saveVoice(profile: VoiceProfile) {
        context.dataStore.edit { prefs ->
            val list = decodeVoices(prefs[voicesKey] ?: "[]").toMutableList()
            list.removeAll { it.id == profile.id }
            list.add(profile)
            prefs[voicesKey] = encodeVoices(list)
        }
    }
    suspend fun setDefaultVoice(id: String) { context.dataStore.edit { it[defaultVoiceKey] = id } }
    suspend fun setAiEnabled(enabled: Boolean) { context.dataStore.edit { it[aiEnabledKey] = enabled } }

    private fun encodeAccounts(items: List<SipAccount>) = JSONArray().apply {
        items.forEach { a -> put(JSONObject().apply {
            put("id",a.id); put("label",a.label); put("username",a.username); put("password",a.password)
            put("server",a.server); put("domain",a.domain); put("ipAddress",a.ipAddress); put("port",a.port)
            put("proxy",a.proxy); put("authId",a.authId); put("callerId",a.callerId)
            put("displayName",a.displayName); put("transport",a.transport); put("stun",a.stun); put("enabled",a.enabled)
        }) }
    }.toString()
    private fun decodeAccounts(raw: String): List<SipAccount> = runCatching {
        val arr = JSONArray(raw); (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            SipAccount(id=o.optString("id"), label=o.optString("label"), username=o.optString("username"),
                password=o.optString("password"), server=o.optString("server"), domain=o.optString("domain"),
                ipAddress=o.optString("ipAddress"), port=o.optInt("port",5060), proxy=o.optString("proxy"),
                authId=o.optString("authId"), callerId=o.optString("callerId"), displayName=o.optString("displayName"),
                transport=o.optString("transport","UDP"), stun=o.optString("stun"), enabled=o.optBoolean("enabled",true))
        }
    }.getOrDefault(emptyList())
    private fun encodeVoices(items: List<VoiceProfile>) = JSONArray().apply {
        items.forEach { v -> put(JSONObject().apply { put("id",v.id); put("name",v.name); put("providerProfileId",v.providerProfileId) }) }
    }.toString()
    private fun decodeVoices(raw: String): List<VoiceProfile> = runCatching {
        val arr=JSONArray(raw); (0 until arr.length()).map { i ->
            val o=arr.getJSONObject(i)
            VoiceProfile(id=o.optString("id"), name=o.optString("name"), providerProfileId=o.optString("providerProfileId"))
        }
    }.getOrDefault(emptyList())
}
