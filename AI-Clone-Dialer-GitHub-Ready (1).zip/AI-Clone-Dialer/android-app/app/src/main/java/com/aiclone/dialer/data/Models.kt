package com.aiclone.dialer.data

import java.util.UUID

data class SipAccount(
    val id: String = UUID.randomUUID().toString(),
    val label: String,
    val username: String,
    val password: String,
    val server: String,
    val domain: String = "",
    val ipAddress: String = "",
    val port: Int = 5060,
    val proxy: String = "",
    val authId: String = "",
    val callerId: String = "",
    val displayName: String = "",
    val transport: String = "UDP",
    val stun: String = "",
    val enabled: Boolean = true
)

data class VoiceProfile(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val providerProfileId: String
)
