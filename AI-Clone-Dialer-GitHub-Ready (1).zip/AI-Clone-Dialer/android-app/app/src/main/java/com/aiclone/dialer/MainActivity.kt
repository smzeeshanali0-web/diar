package com.aiclone.dialer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aiclone.dialer.data.AppRepository
import com.aiclone.dialer.data.SipAccount
import com.aiclone.dialer.data.VoiceProfile
import com.aiclone.dialer.sip.SipEngine
import com.aiclone.dialer.sip.SipEngineStatus
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val repository = AppRepository(applicationContext)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                DialerApp(repository)
            }
        }
    }
}

@Composable
private fun DialerApp(repository: AppRepository) {
    val scope = rememberCoroutineScope()
    val accounts by repository.accounts.collectAsState(initial = emptyList())
    val voices by repository.voices.collectAsState(initial = emptyList())
    val defaultVoice by repository.defaultVoice.collectAsState(initial = "")
    val aiEnabled by repository.aiEnabled.collectAsState(initial = true)
    var tab by remember { mutableStateOf("Dialer") }
    var number by remember { mutableStateOf("") }
    var showSip by remember { mutableStateOf(false) }
    var showVoice by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("SIP engine not configured") }
    var activeAccount by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("AI Clone Dialer") },
                actions = {
                    IconButton(onClick = { showSip = true }) {
                        Icon(Icons.Default.Settings, contentDescription = "SIP settings")
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                listOf("Dialer", "Accounts", "Voice Studio", "Settings").forEach { item ->
                    NavigationBarItem(
                        selected = tab == item,
                        onClick = { tab = item },
                        icon = {
                            Icon(
                                when (item) {
                                    "Dialer" -> Icons.Default.Dialpad
                                    "Accounts" -> Icons.Default.AccountCircle
                                    "Voice Studio" -> Icons.Default.GraphicEq
                                    else -> Icons.Default.Settings
                                }, contentDescription = item
                            )
                        },
                        label = { Text(item) }
                    )
                }
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            when (tab) {
                "Dialer" -> {
                    Text("SIP status: $status", style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = number, onValueChange = { number = it },
                        label = { Text("Phone number / SIP URI") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(12.dp))
                    val keys = listOf("1","2","3","4","5","6","7","8","9","*","0","#")
                    keys.chunked(3).forEach { row ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            row.forEach { key ->
                                OutlinedButton(
                                    onClick = { number += key },
                                    modifier = Modifier.weight(1f).height(54.dp)
                                ) { Text(key) }
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                val account = accounts.firstOrNull { it.id == activeAccount }
                                    ?: accounts.firstOrNull { it.enabled }
                                if (account == null) status = "Add and enable a SIP account first"
                                else if (number.isBlank()) status = "Enter a destination number"
                                else status = "SIP engine adapter required: ${account.label}"
                            },
                            modifier = Modifier.weight(1f)
                        ) { Icon(Icons.Default.Call, null); Spacer(Modifier.width(6.dp)); Text("Call") }
                        OutlinedButton(onClick = { number = number.dropLast(1) }) {
                            Icon(Icons.Default.Backspace, "Delete")
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("Default AI voice: ${voices.firstOrNull { it.id == defaultVoice }?.name ?: "None"}")
                    Text("AI voice conversion: ${if (aiEnabled) "ON" else "OFF"}")
                    Text("Calls must disclose AI-generated voice to the other participant.",
                        style = MaterialTheme.typography.bodySmall)
                }
                "Accounts" -> {
                    Text("SIP accounts", style = MaterialTheme.typography.titleLarge)
                    Button(onClick = { showSip = true }) { Text("Add / edit SIP account") }
                    LazyColumn {
                        items(accounts) { account ->
                            Card(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                                Column(Modifier.padding(12.dp)) {
                                    Text(account.label, style = MaterialTheme.typography.titleMedium)
                                    Text("${account.username}@${account.server}:${account.port}")
                                    Text(if (account.enabled) "Enabled" else "Disabled")
                                    Row {
                                        TextButton(onClick = { activeAccount = account.id }) { Text("Select") }
                                        TextButton(onClick = { showSip = true }) { Text("Manage") }
                                    }
                                }
                            }
                        }
                    }
                }
                "Voice Studio" -> {
                    Text("AI Voice Studio", style = MaterialTheme.typography.titleLarge)
                    Text("Upload an authorized voice sample through the backend integration.")
                    Button(onClick = { showVoice = true }) { Text("Add voice profile") }
                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Text("Use AI voice by default", Modifier.weight(1f))
                        Switch(checked = aiEnabled, onCheckedChange = {
                            scope.launch { repository.setAiEnabled(it) }
                        })
                    }
                    LazyColumn {
                        items(voices) { voice ->
                            Card(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                                Column(Modifier.padding(12.dp)) {
                                    Text(voice.name)
                                    Text(if (voice.id == defaultVoice) "Default voice" else "Saved profile")
                                    TextButton(onClick = {
                                        scope.launch { repository.setDefaultVoice(voice.id) }
                                    }) { Text("Set as default") }
                                }
                            }
                        }
                    }
                }
                else -> {
                    Text("Settings", style = MaterialTheme.typography.titleLarge)
                    Text("AI voice selection is persistent. SIP credentials are stored locally in app preferences in this starter build; production must migrate secrets to Android Keystore encryption.")
                    Text("Backend URL and licensed voice provider must be configured before live cloning.")
                }
            }
        }
    }

    if (showSip) SipAccountDialog(
        onDismiss = { showSip = false },
        onSave = { account ->
            scope.launch { repository.saveAccount(account) }
            showSip = false
        }
    )
    if (showVoice) VoiceProfileDialog(
        onDismiss = { showVoice = false },
        onSave = { profile ->
            scope.launch {
                repository.saveVoice(profile)
                repository.setDefaultVoice(profile.id)
            }
            showVoice = false
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SipAccountDialog(onDismiss: () -> Unit, onSave: (SipAccount) -> Unit) {
    var label by remember { mutableStateOf("My SIP") }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var server by remember { mutableStateOf("") }
    var domain by remember { mutableStateOf("") }
    var proxy by remember { mutableStateOf("") }
    var authId by remember { mutableStateOf("") }
    var callerId by remember { mutableStateOf("") }
    var displayName by remember { mutableStateOf("") }
    var port by remember { mutableStateOf("5060") }
    var transport by remember { mutableStateOf("UDP") }
    var ip by remember { mutableStateOf("") }
    var stun by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("SIP account configuration") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                item { SipField("Account name", label) { label = it } }
                item { SipField("SIP Username", username) { username = it } }
                item { OutlinedTextField(password, { password = it }, label = { Text("SIP Password") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth()) }
                item { SipField("SIP Server / Domain", server) { server = it } }
                item { SipField("SIP Domain (optional)", domain) { domain = it } }
                item { SipField("SIP IP address (optional)", ip) { ip = it } }
                item { SipField("Port", port) { port = it } }
                item { SipField("SIP Proxy", proxy) { proxy = it } }
                item { SipField("Authentication ID", authId) { authId = it } }
                item { SipField("Caller ID", callerId) { callerId = it } }
                item { SipField("Display name", displayName) { displayName = it } }
                item { SipField("STUN server", stun) { stun = it } }
                item {
                    var expanded by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(expanded, { expanded = it }) {
                        OutlinedTextField(transport, {}, readOnly = true, label = { Text("Transport") },
                            modifier = Modifier.menuAnchor().fillMaxWidth())
                        ExposedDropdownMenu(expanded, { expanded = false }) {
                            listOf("UDP", "TCP", "TLS").forEach {
                                DropdownMenuItem(text = { Text(it) }, onClick = { transport = it; expanded = false })
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (username.isNotBlank() && server.isNotBlank()) onSave(
                    SipAccount(label = label, username = username, password = password,
                        server = server, domain = domain, ipAddress = ip, port = port.toIntOrNull() ?: 5060,
                        proxy = proxy, authId = authId, callerId = callerId,
                        displayName = displayName, transport = transport, stun = stun)
                )
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun SipField(label: String, value: String, onValue: (String) -> Unit) {
    OutlinedTextField(value, onValue, label = { Text(label) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
}

@Composable
private fun VoiceProfileDialog(onDismiss: () -> Unit, onSave: (VoiceProfile) -> Unit) {
    var name by remember { mutableStateOf("") }
    var sampleRef by remember { mutableStateOf("") }
    var consent by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add authorized voice profile") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Voice profile name") })
                OutlinedTextField(sampleRef, { sampleRef = it }, label = { Text("Backend sample ID (after upload)") })
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Checkbox(consent, { consent = it })
                    Text("I own this voice or have explicit permission to clone it.")
                }
                Text("MP3 upload and actual model creation require a configured licensed AI provider.",
                    style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (name.isNotBlank() && sampleRef.isNotBlank() && consent) {
                    onSave(VoiceProfile(name = name, providerProfileId = sampleRef))
                }
            }) { Text("Save profile") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
