# Production integration checklist

## 1. SIP / telephony

- Select and license a SIP SDK (PJSIP/PJSUA2 or equivalent).
- Implement `SipEngine` with account registration, digest authentication, UDP/TCP/TLS, proxy, STUN/TURN, codec negotiation, incoming/outgoing calls, DTMF, hold, mute, speaker and Bluetooth routing.
- Confirm that the SIP provider permits the chosen client and outbound caller ID.
- Use the provider's documented host/domain/port/transport values. A Vici Dialer account is not automatically transferable from its private app storage; enter credentials manually or use an authorized export.
- Integrate converted audio into the **outgoing** media path before RTP encoding. Do not modify incoming audio.
- Handle Android foreground-service and microphone permissions for ongoing calls.

## 2. Voice conversion

- Choose a licensed service/model that explicitly supports voice cloning and low-latency streaming conversion.
- Require voice-owner consent and retain the consent record.
- Verify language support, sample duration/quality requirements, latency, concurrency, retention and deletion policy.
- Implement provider streaming over a secure transport. The provider adapter must accept streaming PCM frames and emit converted PCM frames.
- If conversion is unavailable, fail closed: do not silently send the user's unconverted voice when AI voice is enabled.
- Clearly disclose AI-generated voice to the other participant and follow applicable local laws and provider terms.

## 3. Security

- Never commit SIP passwords, AI API keys, voice samples or voice embeddings.
- Use Android Keystore for secrets and TLS for backend traffic.
- Add authenticated users, rate limiting, upload size limits, malware/content checks and retention controls.
- Provide deletion of samples and derived voice profiles.
- Add audit logs for profile creation/deletion and consent.

## 4. Acceptance tests

- SIP registration and re-registration.
- Incoming and outgoing two-device calls.
- DTMF, hold, mute, speaker, Bluetooth and network handoff.
- Voice sample upload with explicit owner authorization.
- Profile persistence after process death and device restart.
- Real-time bidirectional call with converted audio only on the outgoing leg.
- Conversion outage must not silently fall back to raw microphone audio.
- AI disclosure is visible and/or audible as legally required.
