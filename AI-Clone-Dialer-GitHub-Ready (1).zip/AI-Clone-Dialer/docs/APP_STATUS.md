# Current implementation status

## Included in this starter
- Android Compose dialer UI and navigation.
- Editable SIP account form with common fields.
- Local persistence for SIP account metadata and default voice selection.
- Voice profile metadata UI and authorization acknowledgement.
- FastAPI sample upload endpoint with file type/size validation.
- Voice profile list/rename/delete endpoints.
- Explicit non-working boundaries for real SIP and AI provider operations.

## Not yet implemented / not production-ready
- PJSIP SDK/native integration and actual SIP registration/calls.
- RTP audio bridge and outgoing PCM interception.
- Licensed AI provider adapter for voice cloning.
- Low-latency streaming conversion WebSocket pipeline.
- Authentication, PostgreSQL, Android Keystore encryption and production storage.
- APK compilation and two-device validation.

The Android screen intentionally reports that the SIP adapter is required rather than claiming calls work. The backend intentionally returns 501 rather than faking a clone.
